* =====================================================================
* PURPOSE  First regressions for the report: pooled OLS with year effects
* INPUTS   data/processed/sample.dta
* OUTPUTS  output/tables/regressions.docx, output/logs/catchup_4_regressions.log
* CREATED  22 Oct 2026, Lab 1 demo (teacher's version)
* =====================================================================
version 18
if "$root" == "" {
    display as error "Run master.do (or dofiles/0_settings.do) first: it tells Stata where your project is."
    exit 198
}
cap log close
log using "$root/output/logs/catchup_4_regressions.log", replace text
use "$root/data/processed/sample.dta", clear

* -- C1. Pooled OLS with year effects, standard errors clustered by firm
regress ln_dep ai_firm ln_emp ln_cap i.year, vce(cluster firmID)
estimates store clustered

* -- C2. STOP: the AI dummy in a log outcome, log points vs per cent
display "Log points: " %9.6f _b[ai_firm] "   Per cent: " %5.1f 100*(exp(_b[ai_firm]) - 1)

* -- C3. Robust instead of clustered: same coefficient, different standard error
regress ln_dep ai_firm ln_emp ln_cap i.year, vce(robust)
estimates store robust

* -- C4. One table for the report (Stata 17+: etable)
etable, estimates(clustered robust) keep(ai_firm ln_emp ln_cap) ///
    mstat(N) mstat(r2) showstars showstarsnote ///
    column(estimates) note("Standard errors clustered by firm (1), robust (2). Year effects included.") ///
    export("$root/output/tables/regressions.docx", replace)

log close
