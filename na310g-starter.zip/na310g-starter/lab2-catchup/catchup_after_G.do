* Lost during block G? This runs the teacher's code for the demo and copies it
* into your dofiles/ (it REPLACES what is there). Then continue with block the AI task.
* Run master.do first: it sets $root, the project folder.
capture confirm file "$root/data/processed/sample.dta"
if _rc do "$root/lab1-catchup/catchup_after_B.do"     // no Lab 1 sample yet: build it first
copy "$root/lab2-catchup/4_regressions.do" "$root/dofiles/4_regressions.do", replace
do "$root/lab2-catchup/4_regressions.do"
copy "$root/lab2-catchup/5_tests_iv.do" "$root/dofiles/5_tests_iv.do", replace
do "$root/lab2-catchup/5_tests_iv.do"
display as result "Caught up: continue with block the AI task."
