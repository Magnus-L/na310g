* =====================================================================
* PURPOSE  Choose your sample (industry, counties) and create your variables
* INPUTS   (fill in)
* OUTPUTS  (fill in)
* CREATED  <date>, <your code>
* =====================================================================
version 18
if "$root" == "" {
    display as error "Run master.do (or dofiles/0_settings.do) first: it tells Stata where your project is."
    exit 198
}
cap log close
log using "$root/output/logs/2_sample_vars.log", replace text

* Your code here. Comment WHY, not only what.


log close
