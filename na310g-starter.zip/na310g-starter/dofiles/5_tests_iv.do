* =====================================================================
* PURPOSE  Tests on the preferred model, and (if you have one) an instrumental-variables attempt
* INPUTS   (fill in)
* OUTPUTS  (fill in)
* CREATED  <date>, <your code>
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close    // closes a log left open if the last run stopped with an error
log using "$root/output/logs/5_tests_iv.log", replace text

* Your code here. Comment WHY, not only what.


log close
