* =====================================================================
* PURPOSE  Settings used by every do-file: where the project lives, Stata version, seed
* CREATED  <date>, <your code>
* =====================================================================
* Every time you open Stata: run master.do, or this file, BEFORE anything else.
* Otherwise $root is empty and no do-file finds its files.
version 18

* Where the project lives. master.do sets it when you double-click it. If you open Stata
* some other way, go to this folder first (File > Change Working Directory), then run this file.
if "$root" == "" global root "`c(pwd)'"
capture confirm file "$root/master.do"
if _rc {
    display as error "Stata is not in your project folder (it is in: $root)."
    display as error "Use File > Change Working Directory, choose na310g-starter, and run this file again."
    global root ""
    exit 198
}
cd "$root"
display "Project folder: $root"

* Stata 18 or newer is needed (dtable). Check:
if c(stata_version) < 18 display as error "You have Stata " c(stata_version) ": install Stata 18 from the ORU licence page."
set more off
set seed 20261022
