* =====================================================================
* PURPOSE  Tests on the preferred model, and (if you have one) an instrumental-variables attempt
* INPUTS   (fill in)
* OUTPUTS  (fill in)
* CREATED  <date>, <your code>
* =====================================================================
version 18
if "$root" == "" {
    display as error "Run master.do (or dofiles/0_settings.do) first: it tells Stata where your project is."
    exit 198
}
cap log close
log using "$root/output/logs/5_tests_iv.log", replace text

* Your code here. Comment WHY, not only what.


log close
