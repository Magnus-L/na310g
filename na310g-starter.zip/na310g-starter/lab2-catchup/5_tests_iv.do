* =====================================================================
* PURPOSE  Tests on the preferred model, and an instrumental-variables attempt
* INPUTS   data/processed/sample.dta
* OUTPUTS  output/logs/catchup_5_tests_iv.log
* CREATED  26 Oct 2026, Lab 2 demo (teacher's version)
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close    // closes a log left open if the last run stopped with an error
log using "$root/output/logs/catchup_5_tests_iv.log", replace text
use "$root/data/processed/sample.dta", clear
xtset firmID year

* -- F1. Heteroskedasticity (Wooldridge's LM version of Breusch-Pagan): after pooled OLS
*    with default standard errors. With almost 9,000 rows almost any test rejects; we use
*    clustered standard errors anyway, which also allow for serial correlation.
regress ln_fin ai_firm ln_emp ln_cap i.year
estat hettest, rhs iid

* -- F2. Multicollinearity: look at the VIF of the variable you care about (ai_firm),
*    not the mean, which mostly averages the year dummies. "Above 10" is a rule of thumb.
estat vif

* -- F3. Joint significance: do employment and capital matter together?
xtreg ln_fin ai_firm ln_emp ln_cap i.year, fe vce(cluster firmID)
test ln_emp ln_cap

* -- G1. IV: the AI exposure of the firm's main occupation as an instrument for ai_firm.
*    We run it to see what a doubtful instrument looks like. Only firm-years with ads have a
*    main occupation: a smaller, selected sample.
keep if !missing(daioe_main)
count
*    OLS on the same sample, for a like-with-like comparison
regress ln_fin ai_firm ln_emp ln_cap i.year, vce(cluster firmID)
*    First stage first, then the reduced form, then 2SLS
regress ai_firm daioe_main ln_emp ln_cap i.year, vce(cluster firmID)
test daioe_main
regress ln_fin daioe_main ln_emp ln_cap i.year, vce(cluster firmID)
*    (with one instrument, the reduced form's test of daioe_main is the weak-IV-robust
*     test of "AI has no effect")
ivregress 2sls ln_fin (ai_firm = daioe_main) ln_emp ln_cap i.year, vce(cluster firmID)
display _b[ai_firm]
estat firststage

* -- G2. Hausman said fixed effects, so a referee asks for IV with firm fixed effects too
xtivreg ln_fin ln_emp ln_cap i.year (ai_firm = daioe_main), fe vce(cluster firmID) first
display _b[ai_firm]
*    STOP: relevance is tested; exclusion is an argument. Firms that hire for exposed
*    occupations may also finance themselves differently (leasing, debt), so exposure
*    can move financial expenses directly.

log close
