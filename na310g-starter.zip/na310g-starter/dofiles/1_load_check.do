* =====================================================================
* PURPOSE  Load the course data and check it: rows, keys, missing, zeros and negatives
* INPUTS   (fill in)
* OUTPUTS  (fill in)
* CREATED  <date>, <your code>
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close    // closes a log left open if the last run stopped with an error
log using "$root/output/logs/1_load_check.log", replace text

* Your code here. Comment WHY, not only what.


log close
