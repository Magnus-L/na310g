* =====================================================================
* PURPOSE  Descriptive statistics and correlations for the report
* INPUTS   data/processed/analysis.dta
* OUTPUTS  output/tables/descriptives.txt, output/tables/means_by_ai.txt
* CREATED  <date>, <your code>
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close step    // closes this step's own log if a previous run stopped with an error (named, so master.log in batch mode stays open)
log using "$root/output/logs/3_descriptives.log", replace text name(step)

* AI: code in this file was written with Claude (Claude Code) and checked by running it.
use "$root/data/processed/analysis.dta", clear
xtset firmID year

* Overall summary statistics
summ salary_pe ln_sal ai_firm ln_emp ln_kpe ny_solid bslov_antanst, detail
tabstat salary_pe ln_sal ai_firm bslov_antanst ln_emp ln_kpe ny_solid, ///
    statistics(n mean sd min p50 max) columns(statistics) format(%9.3f)

* Group comparison: AI-advertising firm-years vs others
tabstat salary_pe ln_sal bslov_antanst ln_emp ln_kpe ny_solid, by(ai_firm) ///
    statistics(n mean sd) columns(statistics) format(%9.3f)
ttest ln_sal, by(ai_firm)

* Development over time
tabstat ai_firm ln_sal, by(year) statistics(n mean) format(%9.3f)

* Within vs between variation (matters for FE: ai_firm identified from switchers only)
xtsum ln_sal ai_firm ln_emp ln_kpe ny_solid

* Correlations
pwcorr ln_sal ai_firm ln_emp ln_kpe ny_solid, sig star(.05)

* Plain-text tables for the report
tempname fh
file open `fh' using "$root/output/tables/descriptives.txt", write text replace
file write `fh' "Variable | N | Mean | SD | Min | Max" _n
foreach v in salary_pe ln_sal ai_firm bslov_antanst ln_emp ln_kpe ny_solid {
    quietly summ `v'
    local lab : variable label `v'
    file write `fh' "`lab' (`v') | " (r(N)) " | " %9.3f (r(mean)) " | " %9.3f (r(sd)) " | " %9.3f (r(min)) " | " %9.3f (r(max)) _n
}
file close `fh'

log close step
