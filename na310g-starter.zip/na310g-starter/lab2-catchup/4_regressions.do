* =====================================================================
* PURPOSE  Regressions for the report: pooled OLS, fixed effects, random effects
* INPUTS   data/processed/sample.dta
* OUTPUTS  output/tables/regressions.docx, output/logs/catchup_4_regressions.log
* CREATED  22 Oct 2026 (Lab 1), extended 26 Oct 2026 (Lab 2), teacher's version
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close    // closes a log left open if the last run stopped with an error
log using "$root/output/logs/catchup_4_regressions.log", replace text
use "$root/data/processed/sample.dta", clear

* -- C1. Pooled OLS with year effects, standard errors clustered by firm
regress ln_fin ai_firm ln_emp ln_cap i.year, vce(cluster firmID)
estimates store clustered                // stored: the table at the end shows both models

* -- C2. STOP: the AI dummy in a log outcome: log points, then per cent
display _b[ai_firm]
display 100*(exp(_b[ai_firm]) - 1)

* -- C3. Robust instead of clustered: same coefficient, different standard error
regress ln_fin ai_firm ln_emp ln_cap i.year, vce(robust)
estimates store robust                   // stored for the table

* -- C4. One table for the report, straight to Word, ready to paste: (1) clustered, (2) robust.
*    collect is Stata's own table system (etable and dtable are built on it). Each line
*    below sets one thing you can see in the table. To adapt it: change the labels and the note.
collect clear
collect create regtable
*    Put each stored model into the table: its column number, its name, and two Yes/No rows
estimates restore clustered
quietly collect _r_b _r_se _r_p e(N) e(r2), tag(model[(1)] method[cl]): estimates replay
collect get firmfe = "No" yearfe = "Yes", tags(model[(1)] method[cl])
estimates restore robust
quietly collect _r_b _r_se _r_p e(N) e(r2), tag(model[(2)] method[rob]): estimates replay
collect get firmfe = "No" yearfe = "Yes", tags(model[(2)] method[rob])
*    Column heads and row labels (short labels here; the variable labels stay as they are)
collect label levels method cl "Clustered SE" rob "Robust SE", modify
collect label levels colname ai_firm "AI firm" ln_emp "Log employees" ln_cap "Log capital", modify
collect label levels result firmfe "Firm fixed effects" yearfe "Year effects" N "Observations" ///
    r2 "R-squared", modify
*    Numbers: three decimals, standard errors in parentheses, stars on the coefficient
collect style cell result[_r_b _r_se], nformat(%9.3f)
collect style cell result[_r_se], sformat("(%s)")
collect style cell result[N], nformat(%9.0fc)
collect style cell result[r2], nformat(%9.2f)
collect stars _r_p 0.01 "***" 0.05 "**" 0.1 "*", attach(_r_b)
*    Look: no label on coefficient and SE rows, centred numbers, no vertical line,
*    a line between the coefficients and the rows below them
collect style header result[_r_b _r_se], level(hide)
collect style cell, halign(center)
collect style cell cell_type[row-header], halign(left)
collect style cell border_block, border(right, pattern(nil))
collect style cell result[firmfe], border(top, pattern(single))
*    Rows: each variable (coefficient, SE below), then the other rows. Columns: (1), then the name
collect layout (colname[ai_firm ln_emp ln_cap]#result[_r_b _r_se] ///
    result[firmfe yearfe N r2]) (model#method)
collect title "Table 2. AI adoption and financial expenses: pooled OLS"
collect notes "Notes: The dependent variable is log financial expenses."
collect notes "Standard errors in parentheses: clustered by firm in (1), robust in (2)."
collect notes "*** p<0.01, ** p<0.05, * p<0.1."
collect preview
collect export "$root/output/tables/regressions.docx", replace

* =====================================================================
* LAB 2: everything below is new. The Lab 1 part above stays as it is.
* =====================================================================

* -- Start of Lab 2: reload the sample and declare the panel: firm, then year.
*    The stored models from Lab 1 (clustered, robust) survive the reload.
use "$root/data/processed/sample.dta", clear
xtset firmID year

* -- E1. STOP: fixed effects compare each firm with ITSELF over time. With i.year this
*    is two-way FE: a common shock each year, and each firm against itself.
xtreg ln_fin ai_firm ln_emp ln_cap i.year, fe vce(cluster firmID)
estimates store fe
display _b[ai_firm]
*    The three R-squared: within (over time, inside firms), between (across firms'
*    averages), overall. For FE, report the within R-squared.
*    We still cluster: FE remove a firm's permanent level, not the persistence of its shocks.

* -- E1b. FE learn only from firms that SWITCH AI status. How many are there?
*    A firm that never uses AI, or always does, has no change in ai_firm over time,
*    so FE (each firm against itself) learn nothing from it.
bysort firmID: egen ever_ai  = max(ai_firm)    // 1 if the firm is an AI firm in at least one year
bysort firmID: egen always_ai = min(ai_firm)   // 1 if the firm is an AI firm in every year
egen byte firm_tag = tag(firmID)               // 1 on one row per firm: count firms, not rows
count if firm_tag & ever_ai == 1 & always_ai == 0     // AI in some years, not all: the switchers

* -- E2. Random effects: uses variation within AND between firms
xtreg ln_fin ai_firm ln_emp ln_cap i.year, re vce(cluster firmID)
estimates store re

* -- E3. Hausman. H0: the firm effects are unrelated to the regressors (then both are
*    consistent and RE is more precise). It needs the default standard errors.
*    hausman compares two stored models, so we store both
quietly xtreg ln_fin ai_firm ln_emp ln_cap i.year, fe
estimates store fe_h
quietly xtreg ln_fin ai_firm ln_emp ln_cap i.year, re
estimates store re_h
hausman fe_h re_h, sigmamore

* -- E4. The robust version (Wooldridge 14-3, correlated random effects): add each firm's
*    averages to RE, of the regressors AND of the year dummies (the panel is unbalanced).
*    If the averages of the regressors matter, RE's assumption fails: use FE.
bysort firmID: egen m_ai_firm = mean(ai_firm)
bysort firmID: egen m_ln_emp  = mean(ln_emp)
bysort firmID: egen m_ln_cap  = mean(ln_cap)
*    The year averages: (year == 2019) is 1 in 2019 and 0 otherwise, so its firm mean is the
*    share of the firm's years that are 2019. Needed because firms are observed in different years.
bysort firmID: egen m_y2019 = mean(year == 2019)
bysort firmID: egen m_y2020 = mean(year == 2020)
bysort firmID: egen m_y2021 = mean(year == 2021)
bysort firmID: egen m_y2022 = mean(year == 2022)
bysort firmID: egen m_y2023 = mean(year == 2023)
bysort firmID: egen m_y2024 = mean(year == 2024)
xtreg ln_fin ai_firm ln_emp ln_cap m_ai_firm m_ln_emp m_ln_cap m_y* i.year, re vce(cluster firmID)
test m_ai_firm m_ln_emp m_ln_cap
*    H0: all three averages are 0 together (RE is fine). Rejected: the firm effect is tied to
*    the regressors, so use FE. The year averages are controls here, not part of the test.

* -- E5. One table for the report, straight to Word, ready to paste: pooled, FE, RE.
*    collect is Stata's own table system (etable and dtable are built on it). Each line
*    below sets one thing you can see in the table. To adapt it: change the labels and the note.
collect clear
collect create regtable
*    Put each stored model into the table: its column number, its name, and three Yes/No rows
estimates restore clustered     // C1 from Lab 1: the pooled OLS
quietly collect _r_b _r_se _r_p e(N) e(r2), tag(model[(1)] method[ols]): estimates replay
collect get firmfe = "No" firmre = "No" yearfe = "Yes", tags(model[(1)] method[ols])
estimates restore fe
quietly collect _r_b _r_se _r_p e(N) e(r2_w) e(r2_o), tag(model[(2)] method[fe]): estimates replay
collect get firmfe = "Yes" firmre = "No" yearfe = "Yes", tags(model[(2)] method[fe])
estimates restore re
quietly collect _r_b _r_se _r_p e(N) e(r2_w) e(r2_o), tag(model[(3)] method[re]): estimates replay
collect get firmfe = "No" firmre = "Yes" yearfe = "Yes", tags(model[(3)] method[re])
*    Column heads and row labels (short labels here; the variable labels stay as they are)
collect label levels method ols "Pooled OLS" fe "Fixed effects" re "Random effects", modify
collect label levels colname ai_firm "AI firm" ln_emp "Log employees" ln_cap "Log capital", modify
*    R-squared: pooled OLS has one, an overall one, so it goes in the overall row;
*    for FE you report the within R-squared, for RE the overall one
collect recode result r2 = r2_o
collect label levels result firmfe "Firm fixed effects" firmre "Firm random effects" ///
    yearfe "Year effects" N "Observations" r2_w "Within R-squared" r2_o "Overall R-squared", modify
*    Numbers: three decimals, standard errors in parentheses, stars on the coefficient
collect style cell result[_r_b _r_se], nformat(%9.3f)
collect style cell result[_r_se], sformat("(%s)")
collect style cell result[N], nformat(%9.0fc)
collect style cell result[r2_w r2_o], nformat(%9.2f)
collect stars _r_p 0.01 "***" 0.05 "**" 0.1 "*", attach(_r_b)
*    Look: no label on coefficient and SE rows, centred numbers, no vertical line,
*    a line between the coefficients and the rows below them
collect style header result[_r_b _r_se], level(hide)
collect style cell, halign(center)
collect style cell cell_type[row-header], halign(left)
collect style cell border_block, border(right, pattern(nil))
collect style cell result[firmfe], border(top, pattern(single))
*    Rows: each variable (coefficient, SE below), then the other rows. Columns: (1), then the name
collect layout (colname[ai_firm ln_emp ln_cap]#result[_r_b _r_se] ///
    result[firmfe firmre yearfe N r2_w r2_o]) (model#method)
collect title "Table 2. AI adoption and financial expenses"
collect notes "Notes: The dependent variable is log financial expenses."
collect notes "Standard errors clustered by firm in parentheses. *** p<0.01, ** p<0.05, * p<0.1."
collect preview
collect export "$root/output/tables/regressions.docx", replace

log close
