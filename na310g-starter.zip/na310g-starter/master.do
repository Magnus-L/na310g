* =====================================================================
* PURPOSE  Run the whole project, from raw data to tables, in order
* INPUTS   data/raw/
* OUTPUTS  data/processed/, output/tables/, output/logs/
* CREATED  <date>, <your code>
* =====================================================================
* HOW TO START: double-click this file. Stata then opens in this folder.

* $root is the project folder, set once here from the folder Stata opened in. Every path
* below starts from it, so anyone can rerun everything on their own computer.
global root "`c(pwd)'"

do "$root/dofiles/0_settings.do"
do "$root/dofiles/1_load_check.do"
do "$root/dofiles/2_sample_vars.do"
do "$root/dofiles/3_descriptives.do"
do "$root/dofiles/4_regressions.do"
do "$root/dofiles/5_tests_iv.do"

display "Done: everything rebuilt from the raw data"
