# Lab 1, AI task: check what the AI wrote

(Open this file in Notepad on Windows or TextEdit on a Mac. Write your answers at the bottom.)

A student pasted our demo regression into a chatbot and asked it to write the results paragraph.
This is what came back. **It contains at least three mistakes that would cost marks in a report.**
Find them, say why each is wrong, and write the corrected sentence. Use only our output and what
you know: no chatbot.

Our output (pooled OLS with year effects, standard errors clustered by firm):

```
      ln_dep | Coefficient  Std. err.      t    P>|t|     [95% conf. interval]
-------------+----------------------------------------------------------------
     ai_firm |   .1322135    .078272     1.69   0.091    -.0213115    .2857386
      ln_emp |   .2201151   .0269139     8.18   0.000     .1673252    .2729049
      ln_cap |   .7891941    .012981    60.80   0.000     .7637327    .8146555
Number of obs = 16,259     R-squared = 0.71
```

The AI's paragraph:

> Adopting AI increases a firm's depreciation by 13.2 per cent, holding employment and capital
> constant, and the effect is statistically significant at the 5 per cent level. Because the
> standard errors are clustered by firm, the coefficient is unbiased even if AI-adopting firms
> differ from other firms in ways we do not observe. The R-squared of 0.71 shows that the model
> is correctly specified.

Your answers (two or three lines each, in your own words):

1. Mistake 1, and the corrected sentence:
2. Mistake 2, and the corrected sentence:
3. Mistake 3, and the corrected sentence:
4. Anything else:
