* =====================================================================
* PURPOSE  Choose your sample (industry, counties) and create your variables
* INPUTS   both files in data/raw/
* OUTPUTS  data/processed/analysis.dta
* CREATED  <date>, <your code>
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close step    // closes this step's own log if a previous run stopped with an error (named, so master.log in batch mode stays open)
log using "$root/output/logs/2_sample_vars.log", replace text name(step)

* AI: code in this file was written with Claude (Claude Code) and checked by running it.
* SAMPLE CHOICE: all industries and counties are kept (the question is about all large firms).
* Observations are dropped only where the dependent variable cannot be built.

use "$root/data/raw/na310g_data_course.dta", clear
local n0 = _N
display "N start: `n0'"

* Merge the occupation file on the firm's main advertised occupation. Firms without ads have
* no ssyk_main and are kept (_merge==1); occupations never used by a firm (_merge==2) are dropped.
* The occupation-file scores are renamed occ_* so they do not clash with the firm-file means.
rename ssyk_main ssyk2012_4
preserve
    use "$root/data/raw/na310g_occupations_ssyk2012.dta", clear
    keep ssyk2012_4 daioe_pctl daioe_genai_pctl cognitive_abilities social_skills
    rename (daioe_pctl daioe_genai_pctl cognitive_abilities social_skills) ///
           (occ_daioe occ_daioe_genai occ_cognitive occ_social)
    tempfile occ
    save `occ'
restore
merge m:1 ssyk2012_4 using `occ', keep(master match) generate(_mocc)
tab _mocc
display "N after merge: " _N " (must equal `n0')"

* Dependent variable: salary per employee, KSEK. Salaries are recorded negative -> flip the sign.
* Needs employees > 0 and non-missing salaries.
* (Salaries are costs, so after the sign flip every value is zero or positive.)
gen salary_pe = -rr04a_loner / bslov_antanst if bslov_antanst > 0
count if missing(salary_pe)
summarize salary_pe
gen ln_sal = ln(salary_pe) if salary_pe > 0
label variable ln_sal "ln salary per employee (KSEK)"
label variable salary_pe "Salary per employee (KSEK)"

* Controls: size, capital intensity, financial strength. In logs because levels are very skewed.
gen ln_emp  = ln(bslov_antanst) if bslov_antanst > 0
gen ln_kpe  = ln(br09_tillgsu / bslov_antanst) if br09_tillgsu > 0 & bslov_antanst > 0
label variable ln_emp "ln employees"
label variable ln_kpe "ln total assets per employee"
label variable ny_solid "Equity/asset ratio"
* Value added per employee is NOT used as a control: it contains wage costs by construction.

* Winsorising is not used; instead the log specification handles the right skew.
* Sample: non-missing outcome and all controls
gen byte insample = !missing(salary_pe, ln_emp, ln_kpe, ny_solid, ai_firm)
tab insample
keep if insample
display "N analysis sample: " _N

xtset firmID year
* ai_firm only exists for firms with ads, and the IV needs an occupation, so flag it
gen byte iv_sample = !missing(occ_daioe)
tab iv_sample ai_firm

compress
save "$root/data/processed/analysis.dta", replace

log close step
