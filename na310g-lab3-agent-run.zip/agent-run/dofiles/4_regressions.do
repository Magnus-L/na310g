* =====================================================================
* PURPOSE  Regressions and tests for the report
* INPUTS   data/processed/analysis.dta
* OUTPUTS  output/tables/regtable.md, output/tables/hausman.txt
* CREATED  <date>, <your code>
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close step    // closes this step's own log if a previous run stopped with an error (named, so master.log in batch mode stays open)
log using "$root/output/logs/4_regressions.log", replace text name(step)

* AI: code in this file was written with Claude (Claude Code) and checked by running it.
use "$root/data/processed/analysis.dta", clear
xtset firmID year

* Standard errors are clustered by firm everywhere: errors are serially correlated within firm.
local X ai_firm ln_emp ln_kpe ny_solid

* (1) Pooled OLS, no year effects
regress ln_sal `X', vce(cluster firmID)
estimates store m1
* (2) Pooled OLS with year effects
regress ln_sal `X' i.year, vce(cluster firmID)
estimates store m2
* (3) Fixed effects (within), year effects
xtreg ln_sal `X' i.year, fe
estimates store m3
* (4) Random effects, year effects
xtreg ln_sal `X' i.year, re vce(cluster firmID)
estimates store m4

* Hausman test FE vs RE. The classic test is invalid with clustered SEs, so it is run on
* non-robust fits (sigmamore), and complemented with the robust Mundlak (correlated RE) test.
quietly xtreg ln_sal `X' i.year, fe
estimates store fe_plain
quietly xtreg ln_sal `X' i.year, re
estimates store re_plain
hausman fe_plain re_plain, sigmamore
local haus_chi = r(chi2)
local haus_df  = r(df)
local haus_p   = r(p)

* Mundlak: add firm means of the time-varying regressors to RE; joint test of means = 0
foreach v in ai_firm ln_emp ln_kpe ny_solid {
    bysort firmID: egen m_`v' = mean(`v')
}
xtreg ln_sal `X' m_ai_firm m_ln_emp m_ln_kpe m_ny_solid i.year, re vce(cluster firmID)
test m_ai_firm m_ln_emp m_ln_kpe m_ny_solid
local mund_chi = r(chi2)
local mund_p   = r(p)

* Table: coefficient (SE) with stars, via matrices (no user-written packages needed)
local models m1 m2 m3 m4
local vars ai_firm ln_emp ln_kpe ny_solid
tempname fh
file open `fh' using "$root/output/tables/regtable.md", write text replace
file write `fh' "| | (1) Pooled OLS | (2) Pooled OLS + year | (3) Fixed effects | (4) Random effects |" _n
file write `fh' "|---|---|---|---|---|" _n
foreach v of local vars {
    local lab : variable label `v'
    local rb "| `lab' "
    local rs "| "
    foreach m of local models {
        quietly estimates restore `m'
        local b = _b[`v']
        local se = _se[`v']
        local p = 2*ttail(e(df_r), abs(`b'/`se'))
        if "`m'" == "m4" local p = 2*(1-normal(abs(`b'/`se')))
        local st ""
        if `p' < 0.10 local st "*"
        if `p' < 0.05 local st "**"
        if `p' < 0.01 local st "***"
        local rb "`rb'| `=string(`b', "%6.3f")'`st' "
        local rs "`rs'| (`=string(`se', "%6.3f")') "
    }
    file write `fh' "`rb'|" _n "`rs'|" _n
}
local ry "| Year effects "
local rf "| Firm effects "
local rn "| Observations "
local rg "| Firms "
local rr "| R-squared "
foreach m of local models {
    quietly estimates restore `m'
    local ry "`ry'| `=cond("`m'"=="m1","No","Yes")' "
    local rf "`rf'| `=cond("`m'"=="m3","Yes","No")' "
    local rn "`rn'| `=string(e(N), "%9.0fc")' "
    quietly levelsof firmID if e(sample), local(ids)
    local rg "`rg'| `: word count `ids'' "
    local r2 = cond("`m'"=="m3", e(r2_w), cond("`m'"=="m4", e(r2_o), e(r2)))
    local rr "`rr'| `=string(`r2', "%5.3f")' "
}
file write `fh' "`ry'|" _n "`rf'|" _n "`rn'|" _n "`rg'|" _n "`rr'|" _n
file close `fh'

file open `fh' using "$root/output/tables/hausman.txt", write text replace
file write `fh' "Hausman (sigmamore): chi2(" (`haus_df') ") = " %8.3f (`haus_chi') ", p = " %6.4f (`haus_p') _n
file write `fh' "Mundlak joint test: chi2 = " %8.3f (`mund_chi') ", p = " %6.4f (`mund_p') _n
file close `fh'

log close step
