* =====================================================================
* PURPOSE  Choose the sample (industry, counties) and create the variables
* INPUTS   data/processed/checked.dta, data/raw/na310g_occupations_ssyk2012.dta
* OUTPUTS  data/processed/sample.dta, output/logs/catchup_2_sample_vars.log
* CREATED  22 Oct 2026, Lab 1 demo (teacher's version)
* Demo outcome (nobody has it in the report): the firm's financial expenses, against
* AI adoption, size and capital. All industries, Sweden without Kalmar and Västerbotten.
* Chosen because it shows what robust and clustered standard errors and fixed effects
* do; it is a teaching example, not a finding about AI.
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close    // closes a log left open if the last run stopped with an error
log using "$root/output/logs/catchup_2_sample_vars.log", replace text
use "$root/data/processed/checked.dta", clear

* -- B1. Industry groups from the SNI 2007 code. The data store the 2-digit division
*    times 1000 (25000 = division 25). Firms outside the three groups (energy, water,
*    education, health, or no code) get no group: that is by design, not a bug.
gen division = floor(bransch_sni07 / 1000)
gen industry = .
replace industry = 1 if inrange(division, 10, 33)                                 // C manufacturing
replace industry = 2 if inrange(division, 58, 66) | inrange(division, 69, 75)     // J, K, M
replace industry = 3 if inrange(division, 41, 47) | inrange(division, 49, 56) ///
                      | division == 68 | inrange(division, 77, 82) | inrange(division, 94, 96)  // F to S
label define ind 1 "Manufacturing" 2 "Professional services" 3 "Other services"
label values industry ind
tab industry, missing

* -- B2. Geography: drop two counties (Kalmar = 8, Västerbotten = 24)
count
drop if inlist(ser_laen, 8, 24)
count

* -- B3. Variables. Costs are negative in the accounts: flip the sign, then log.
*    Logs of zero or negative values are missing: count them before they vanish.
gen finexp  = -rr09_finkostn
gen ln_fin  = ln(finexp)
gen ln_emp  = ln(bslov_antanst)
gen capital = br02a_byggmark + br03_maskiner
gen ln_cap  = ln(capital)
label variable ln_fin "Log financial expenses"
label variable ln_emp "Log employees"
label variable ln_cap "Log capital (buildings, land, machinery)"
count if missing(ln_fin)
count if missing(ln_emp)
count if missing(ln_cap)

* -- B4. Merge an occupation measure: many firm-years to one occupation (m:1).
*    Goal: the AI exposure of each firm's most advertised occupation (ssyk_main), taken
*    from the occupation file. In Lab 2 it is the instrument for AI adoption.
*    Two snags, and the line that handles each:
*    (1) Our data ALREADY have a variable daioe_pctl: the firm's AVERAGE exposure over
*        all its ads. The occupation file uses the same name for each occupation's
*        exposure. When both files have a variable with the same name, merge keeps the
*        old values and brings in nothing. So we rename ours first (daioe_avg).
rename daioe_pctl daioe_avg
*    (2) merge needs the key under the SAME name in both files. The occupation file
*        calls it ssyk2012_4, so we make a copy of ssyk_main with that name.
gen ssyk2012_4 = ssyk_main
*    keepusing(daioe_pctl): from the occupation file, take only this one variable (the
*    file has other columns we do not need). keep(master match): keep all our
*    firm-years, also those without a match, and drop occupations no firm has.
merge m:1 ssyk2012_4 using "$root/data/raw/na310g_occupations_ssyk2012.dta", ///
    keepusing(daioe_pctl) keep(master match)
tab _merge                                        // 1 = no ads that year, so no main occupation
assert _merge != 2
*    The daioe_pctl that came in is the exposure of the main occupation: name it so.
rename daioe_pctl daioe_main
label variable daioe_main "AI exposure (DAIOE percentile, 0-100) of the firm's most advertised occupation"
drop _merge

* -- B5. The estimation sample, one step at a time, each step counted
count
drop if missing(ln_fin)
count
drop if missing(ln_emp)
count
drop if missing(ln_cap)
count

save "$root/data/processed/sample.dta", replace
log close
