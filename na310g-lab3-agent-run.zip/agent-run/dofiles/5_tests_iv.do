* =====================================================================
* PURPOSE  Tests on the preferred model, and (if you have one) an instrumental-variables attempt
* INPUTS   data/processed/analysis.dta
* OUTPUTS  output/tables/iv_table.md, output/tables/diagnostics.txt
* CREATED  <date>, <your code>
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close step    // closes this step's own log if a previous run stopped with an error (named, so master.log in batch mode stays open)
log using "$root/output/logs/5_tests_iv.log", replace text name(step)

* AI: code in this file was written with Claude (Claude Code) and checked by running it.
use "$root/data/processed/analysis.dta", clear
xtset firmID year
local X ln_emp ln_kpe ny_solid

*---------------- Diagnostics -----------------------------------------------
* F test that all firm effects are zero (FE vs pooled)
xtreg ln_sal ai_firm `X' i.year, fe
display "F test u_i=0: F = " e(F_f) ", p = " Ftail(e(df_a), e(df_r), e(F_f))

* Breusch-Pagan LM test for random effects vs pooled OLS
quietly xtreg ln_sal ai_firm `X' i.year, re
xttest0

* Heteroskedasticity (pooled OLS): Breusch-Pagan / Cook-Weisberg
quietly regress ln_sal ai_firm `X' i.year
estat hettest
* Specification (Ramsey RESET) and multicollinearity (VIF)
estat ovtest
estat vif

* Wooldridge (2002) serial-correlation test, done by hand because xtserial is user-written:
* regress first differences, then test that the lagged residual coefficient equals -0.5.
preserve
    quietly {
        foreach v in ln_sal ai_firm ln_emp ln_kpe ny_solid {
            gen d_`v' = D.`v'
        }
        regress d_ln_sal d_ai_firm d_ln_emp d_ln_kpe d_ny_solid, vce(cluster firmID)
        predict double ehat, resid
        gen double ehat_l = L.ehat
        regress ehat ehat_l d_ai_firm d_ln_emp d_ln_kpe d_ny_solid, vce(cluster firmID)
    }
    display "Wooldridge serial correlation test: H0 coefficient on lagged residual = -0.5"
    test ehat_l = -0.5
restore

* Normality of residuals (skewness/kurtosis)
quietly xtreg ln_sal ai_firm `X' i.year, fe
predict double e_fe, e
sktest e_fe
drop e_fe

*---------------- Instrumental variables ------------------------------------
* Instrument: AI exposure of the firm's main advertised occupation (occupation file, DAIOE
* percentile). Only available for firms that posted ads, so the IV sample is a subsample.
* The two DAIOE measures are nearly the same, so the model is just identified (no over-id test).
count if iv_sample
tab ai_firm if iv_sample

* Reference: OLS and FE on the same IV subsample, so estimates are comparable
regress ln_sal ai_firm `X' i.year if iv_sample, vce(cluster firmID)
estimates store o1
xtreg ln_sal ai_firm `X' i.year if iv_sample, fe vce(cluster firmID)
estimates store o2

* 2SLS pooled with year effects; first stage, relevance (F) and endogeneity test
ivregress 2sls ln_sal `X' i.year (ai_firm = occ_daioe) if iv_sample, vce(cluster firmID) first
estimates store iv1
estat firststage
* Add O*NET cognitive/social content of the occupation to weaken the obvious exclusion problem
ivregress 2sls ln_sal `X' occ_cognitive occ_social i.year (ai_firm = occ_daioe) if iv_sample, vce(cluster firmID) first
estimates store iv2
estat firststage
* Within-firm 2SLS: uses changes in occupation exposure inside a firm over time
xtivreg ln_sal `X' i.year (ai_firm = occ_daioe) if iv_sample, fe vce(cluster firmID) first
estimates store iv3
* Reduced form: does exposure move wages directly? (a direct effect would violate exclusion)
regress ln_sal occ_daioe `X' i.year if iv_sample, vce(cluster firmID)
regress ln_sal occ_daioe `X' i.year if iv_sample & ai_firm == 0, vce(cluster firmID)

* First-stage partial F with FE (the within first stage), by hand
quietly xtreg ai_firm occ_daioe `X' i.year if iv_sample, fe vce(cluster firmID)
test occ_daioe
display "FE first-stage F (cluster robust) = " r(F)

* Table
tempname fh
file open `fh' using "$root/output/tables/iv_table.md", write text replace
file write `fh' "| | OLS (IV sample) | FE (IV sample) | 2SLS | 2SLS + O*NET | FE 2SLS |" _n
file write `fh' "|---|---|---|---|---|---|" _n
local rb "| ai_firm "
local rs "| "
foreach m in o1 o2 iv1 iv2 iv3 {
    quietly estimates restore `m'
    local b = _b[ai_firm]
    local se = _se[ai_firm]
    local z = abs(`b'/`se')
    local p = 2*(1-normal(`z'))
    local st ""
    if `p' < 0.10 local st "*"
    if `p' < 0.05 local st "**"
    if `p' < 0.01 local st "***"
    local rb "`rb'| `=string(`b', "%6.3f")'`st' "
    local rs "`rs'| (`=string(`se', "%6.3f")') "
}
file write `fh' "`rb'|" _n "`rs'|" _n
file close `fh'

log close step
