* =====================================================================
* PURPOSE  Descriptive statistics and correlations for the report
* INPUTS   data/processed/sample.dta
* OUTPUTS  output/tables/descriptives.docx, output/logs/catchup_3_descriptives.log
* CREATED  22 Oct 2026, Lab 1 demo (teacher's version)
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close    // closes a log left open if the last run stopped with an error
log using "$root/output/logs/catchup_3_descriptives.log", replace text
use "$root/data/processed/sample.dta", clear

* -- B6. One table: N, mean, median, SD, min, max, a column each (Stata 18: dtable)
dtable ln_fin ln_emp ln_cap ai_firm, ///
    continuous(, statistics(count mean p50 sd min max)) nformat(%9.2f mean p50 sd min max) ///
    title("Table 1. Descriptive statistics, firm-years") ///
    note("Notes: AI firm is 0 or 1, so its mean is the share of AI firm-years. Capital: buildings, land, machinery.")
collect layout (var) (result[count mean p50 sd min max])
*    Short row labels and column heads (the variable labels stay as they are)
collect label levels var ln_fin "Log financial expenses" ln_emp "Log employees" ///
    ln_cap "Log capital" ai_firm "AI firm (0/1)", modify
collect label levels result count "N" mean "Mean" p50 "Median" sd "SD" min "Min" max "Max", modify
*    Look: SD without parentheses, centred numbers, no vertical line, columns as wide as their text
collect style cell result[sd], sformat("%s")
collect style cell, halign(center)
collect style cell cell_type[row-header], halign(left)
collect style cell border_block, border(right, pattern(nil))
collect style putdocx, layout(autofitcontents)
collect export "$root/output/tables/descriptives.docx", replace

* -- B7. Correlations, with stars at the 5 per cent level
pwcorr ln_fin ln_emp ln_cap ai_firm, star(0.05)

log close
