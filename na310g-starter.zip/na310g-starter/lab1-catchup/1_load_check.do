* =====================================================================
* PURPOSE  Load the course data and check it: rows, keys, missing, zeros and negatives
* INPUTS   data/raw/na310g_data_course.dta
* OUTPUTS  data/processed/checked.dta, output/logs/catchup_1_load_check.log
* CREATED  22 Oct 2026, Lab 1 demo (teacher's version)
* =====================================================================
version 18
if "$root" == "" {
    display as error "Run master.do (or dofiles/0_settings.do) first: it tells Stata where your project is."
    exit 198
}
cap log close
log using "$root/output/logs/catchup_1_load_check.log", replace text

* STOP: raw data are the evidence. We never edit them; we save copies.
* -- A1. Load the raw data
use "$root/data/raw/na310g_data_course.dta", clear

* -- A2. First look: how many rows, which variables, what do they mean?
describe, short
describe bslov_antanst rr05_avskriv br09_tillgsu ai_firm ssyk_main
codebook ai_firm, compact
* (In class also: help isid, and browse)

* -- A3. The key: one row per firm and year? If not, every later step is wrong.
isid firmID year

* -- A4. STOP: know your data. Garbage in, garbage out.
summarize bslov_antanst rr05_avskriv br09_tillgsu
count if bslov_antanst == 0           // firms with no employees: what are they?
count if missing(br09_tillgsu)         // missing accounts
count if rr05_avskriv > 0              // costs are stored with a minus sign
count if rr04a_loner > 0               // salaries too: a trap for your report
tab ai_firm year if inlist(year, 2008, 2014, 2020), col

save "$root/data/processed/checked.dta", replace
log close
