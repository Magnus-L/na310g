* =====================================================================
* PURPOSE  Load the course data and check it: rows, keys, missing, zeros and negatives
* INPUTS   data/raw/na310g_data_course.dta, data/raw/na310g_occupations_ssyk2012.dta
* OUTPUTS  output/logs/1_load_check.log
* CREATED  <date>, <your code>
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close step    // closes this step's own log if a previous run stopped with an error (named, so master.log in batch mode stays open)
log using "$root/output/logs/1_load_check.log", replace text name(step)

* AI: code in this file was written with Claude (Claude Code) and checked by running it.
use "$root/data/raw/na310g_data_course.dta", clear
describe, short

* Panel structure: firmID x year must be unique, otherwise xtset fails and FE is wrong
isid firmID year
xtset firmID year
xtdescribe, patterns(8)

* Money variables are costs recorded as NEGATIVE numbers (CODEBOOK: "as recorded in the accounts").
* Salaries are never positive, so salary per employee must be built with a sign flip.
summ rr04a_loner rr04_perskos bslov_antanst br09_tillgsu rr01_ntoms
count if rr04a_loner > 0 & !missing(rr04a_loner)
count if rr04a_loner == 0
count if missing(rr04a_loner)

* Zero employees: salary per employee is undefined there
count if bslov_antanst == 0
count if bslov_antanst == 0 & rr04a_loner == 0
count if bslov_antanst < 10

* Total assets and sales: zeros/negatives matter for logs
count if br09_tillgsu <= 0 | missing(br09_tillgsu)
count if rr01_ntoms <= 0 | missing(rr01_ntoms)
count if missing(ny_solid)

* Treatment variable: ai_firm can only be 1 if the firm posted ads (has_ads == 1)
tab has_ads ai_firm, missing
* How much does ai_firm vary within firm? FE only uses firms that switch.
bysort firmID: egen _mx = max(ai_firm)
bysort firmID: egen _mn = min(ai_firm)
egen _tag = tag(firmID)
tab _mx _mn if _tag
drop _mx _mn _tag

* Occupation file: one row per 4-digit SSYK (merge key), a few missing scores
use "$root/data/raw/na310g_occupations_ssyk2012.dta", clear
isid ssyk2012_4
summ daioe_pctl daioe_genai_pctl
count if missing(daioe_pctl)
* The two exposure measures are (nearly) identical, so they cannot be two independent instruments
corr daioe_pctl daioe_genai_pctl

* Does the merge key match? Firms with ads have ssyk_main, others do not.
use "$root/data/raw/na310g_data_course.dta", clear
rename ssyk_main ssyk2012_4
merge m:1 ssyk2012_4 using "$root/data/raw/na310g_occupations_ssyk2012.dta", keepusing(daioe_pctl) generate(_m)
tab _m

log close step    // closes this step's own log if a previous run stopped with an error (named, so master.log in batch mode stays open)
log using "$root/output/logs/1_load_check.log", replace text name(step)

* AI: code in this file was written with Claude (Claude Code) and checked by running it.
use "$root/data/raw/na310g_data_course.dta", clear
describe, short

* Panel structure: firmID x year must be unique, otherwise xtset fails and FE is wrong
isid firmID year
xtset firmID year
xtdescribe, patterns(8)

* Money variables are costs recorded as NEGATIVE numbers (CODEBOOK: "as recorded in the accounts").
* Salaries are never positive, so salary per employee must be built with a sign flip.
summ rr04a_loner rr04_perskos bslov_antanst br09_tillgsu rr01_ntoms
count if rr04a_loner > 0 & !missing(rr04a_loner)
count if rr04a_loner == 0
count if missing(rr04a_loner)

* Zero employees: salary per employee is undefined there
count if bslov_antanst == 0
count if bslov_antanst == 0 & rr04a_loner == 0
count if bslov_antanst < 10

* Total assets and sales: zeros/negatives matter for logs
count if br09_tillgsu <= 0 | missing(br09_tillgsu)
count if rr01_ntoms <= 0 | missing(rr01_ntoms)
count if missing(ny_solid)

* Treatment variable: ai_firm can only be 1 if the firm posted ads (has_ads == 1)
tab has_ads ai_firm, missing
* How much does ai_firm vary within firm? FE only uses firms that switch.
bysort firmID: egen _mx = max(ai_firm)
bysort firmID: egen _mn = min(ai_firm)
egen _tag = tag(firmID)
tab _mx _mn if _tag
drop _mx _mn _tag

* Occupation file: one row per 4-digit SSYK (merge key), a few missing scores
use "$root/data/raw/na310g_occupations_ssyk2012.dta", clear
isid ssyk2012_4
summ daioe_pctl daioe_genai_pctl
count if missing(daioe_pctl)
* The two exposure measures are (nearly) identical, so they cannot be two independent instruments
corr daioe_pctl daioe_genai_pctl

* Does the merge key match? Firms with ads have ssyk_main, others do not.
use "$root/data/raw/na310g_data_course.dta", clear
rename ssyk_main ssyk2012_4
merge m:1 ssyk2012_4 using "$root/data/raw/na310g_occupations_ssyk2012.dta", keepusing(daioe_pctl) generate(_m)
tab _m
* Compare the firm-file measure with the occupation-file measure (firm file is an ad-weighted mean)
corr daioe_pctl daioe_pctl

log close step
