* =====================================================================
* PURPOSE  Settings used by every do-file
* CREATED  <date>, <your code>
* =====================================================================
* Run master.do first: it sets $root, the project folder.

cd "$root"           // work in the project folder, so every path is the same on every computer
version 18           // results stay the same in newer Stata versions (any Stata 18 or newer works)
set more off         // let output run without pausing
set seed 20261022    // anything random becomes repeatable
