* =====================================================================
* PURPOSE  Descriptive statistics and correlations for the report
* INPUTS   data/processed/sample.dta
* OUTPUTS  output/tables/descriptives.docx, output/logs/catchup_3_descriptives.log
* CREATED  22 Oct 2026, Lab 1 demo (teacher's version)
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close    // closes a log left open if the last run stopped with an error
log using "$root/output/logs/catchup_3_descriptives.log", replace text
use "$root/data/processed/sample.dta", clear

* -- B6. One table: N, mean, median, SD, min, max, a column each (Stata 18: dtable)
label variable ai_firm "AI firm (ad asking for AI skills)"
dtable ln_fin ln_emp ln_cap ai_firm, ///
    continuous(, statistics(count mean p50 sd min max)) nformat(%9.2f mean p50 sd min max)
collect layout (var) (result[count mean p50 sd min max])
collect export "$root/output/tables/descriptives.docx", replace

* -- B7. Correlations, with stars at the 5 per cent level
pwcorr ln_fin ln_emp ln_cap ai_firm, star(0.05)

log close
