# Your NA310G project

One folder for the labs and your report. Everything you hand in can be rebuilt from here by
running one file, `master.do`.

```
na310g-starter/
├── master.do              runs everything, in order
├── dofiles/
│   ├── 0_settings.do      where the project lives on YOUR computer (edit one line)
│   ├── 1_load_check.do    load the data and check it
│   ├── 2_sample_vars.do   your sample and your variables
│   ├── 3_descriptives.do  descriptive statistics
│   └── 4_regressions.do   regressions and tests
├── data/
│   ├── raw/               the data as you got them: never edit, never overwrite
│   └── processed/         what your do-files save
└── output/
    ├── tables/            tables for the report
    └── logs/              one log per do-file
```

**First time:**
1. Unzip: right-click the zip > *Extract All* (Windows) or double-click (Mac). Never work inside the
   zip. Put the folder in Documents, **not** in OneDrive, Dropbox or iCloud (they can lock files).
2. Put the course data files in `data/raw/`.
3. Double-click `master.do`. Stata opens in this folder and runs everything.

**Every time you open Stata:** double-click `master.do`, or run `dofiles/0_settings.do` first.
To open a do-file and work in it: in Stata, File > Open, or double-click it after the first run.

**The rules:** never touch `data/raw/`; one do-file per step; every do-file starts with its header;
mark lines that came from an AI tool with `* AI:`.
