* Lost during block A? This runs the teacher's code for the demo and copies it
* into your dofiles/ (it REPLACES what is there). Then continue with block B.
* Run master.do first: it sets $root, the project folder.
copy "$root/lab1-catchup/1_load_check.do" "$root/dofiles/1_load_check.do", replace
do "$root/lab1-catchup/1_load_check.do"
display as result "Caught up: continue with block B."
