* =====================================================================
* PURPOSE  Choose your sample (industry, counties) and create your variables
* INPUTS   (fill in)
* OUTPUTS  (fill in)
* CREATED  <date>, <your code>
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close    // closes a log left open if the last run stopped with an error
log using "$root/output/logs/2_sample_vars.log", replace text

* Your code here. Comment WHY, not only what.


log close
