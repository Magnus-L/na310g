* =====================================================================
* PURPOSE  Lab 1 self-check: run it after each block. It says OK, or what differs.
*          Usage:  do "$root/check_lab1.do"
* CREATED  22 Oct 2026, generated from the teacher's demo run (build_lab1.py)
* =====================================================================
* The checks are for the DEMO question we do together in class (depreciation, all
* industries, Sweden without Kalmar and Västerbotten). On your own data it WILL complain.
if "$root" == "" {
    display as error "Run master.do or dofiles/0_settings.do first: Stata does not know where your project is."
    exit
}
preserve

* --- Block A: the checked data
capture confirm file "$root/data/processed/checked.dta"
if _rc {
    display as error "A: data/processed/checked.dta not found. Does your 1_load_check.do end with save?"
    restore
    exit
}
use "$root/data/processed/checked.dta", clear
capture assert _N == 20657
if _rc display as error "A: expected 20657 rows, you have " _N ". Did you drop or add rows in 1_load_check.do?"
else display as result "A: OK, 20657 firm-years, one row per firm and year."

* --- Block B: the sample and the variables
capture confirm file "$root/data/processed/sample.dta"
if _rc {
    display as text "B: not yet (data/processed/sample.dta not found). Fine if you have not done block B."
    restore
    exit
}
use "$root/data/processed/sample.dta", clear
local ok = 1
foreach v in ln_dep ln_emp ln_cap aioe_main industry {
    capture confirm variable `v'
    if _rc {
        display as error "B: variable `v' is missing."
        local ok = 0
    }
}
capture assert !inlist(ser_laen, 8, 24)
if _rc {
    display as error "B: Kalmar (8) or Västerbotten (24) is still in the sample."
    local ok = 0
}
capture assert _N == 16259
if _rc {
    display as error "B: expected 16259 firm-years in the sample, you have " _N "."
    display as error "   Check the two counties, the sign flip before ln(), and the three drop if missing() lines."
    local ok = 0
}
if !`ok' {
    restore
    exit
}
display as result "B: OK, 16259 firm-years with all regression variables."

* --- Block C: the first regression, on your sample
capture quietly regress ln_dep ai_firm ln_emp ln_cap i.year, vce(cluster firmID)
if _rc {
    display as error "C: the regression did not run on your sample (error " _rc ")."
    restore
    exit
}
capture assert abs(_b[ai_firm] - 0.132214) < 0.0001
if _rc display as error "C: the AI coefficient on your sample is " %6.3f _b[ai_firm] ", expected 0.132."
else display as result "C: OK, AI coefficient 0.132 log points. In per cent: 100*(exp(b) - 1)."

restore
