* Lost during block A? This runs the teacher's code for the demo and copies it
* into your dofiles/ (it REPLACES what is there). Then continue with block B.
if "$root" == "" {
    display as error "Run master.do or dofiles/0_settings.do first."
    exit 198
}
copy "$root/lab1-catchup/1_load_check.do" "$root/dofiles/1_load_check.do", replace
do "$root/lab1-catchup/1_load_check.do"
display as result "Caught up: continue with block B."
