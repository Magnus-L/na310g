* =====================================================================
* PURPOSE  First regressions for the report: pooled OLS with year effects
* INPUTS   data/processed/sample.dta
* OUTPUTS  output/tables/regressions.docx, output/logs/catchup_4_regressions.log
* CREATED  22 Oct 2026, Lab 1 demo (teacher's version)
* =====================================================================
version 18
* Run master.do first: it sets $root, the project folder.
capture log close    // closes a log left open if the last run stopped with an error
log using "$root/output/logs/catchup_4_regressions.log", replace text
use "$root/data/processed/sample.dta", clear

* -- C1. Pooled OLS with year effects, standard errors clustered by firm
regress ln_fin ai_firm ln_emp ln_cap i.year, vce(cluster firmID)
estimates store clustered                // stored: the table at the end shows both models

* -- C2. STOP: the AI dummy in a log outcome: log points, then per cent
display _b[ai_firm]
display 100*(exp(_b[ai_firm]) - 1)

* -- C3. Robust instead of clustered: same coefficient, different standard error
regress ln_fin ai_firm ln_emp ln_cap i.year, vce(robust)
estimates store robust                   // stored for the table

* -- C4. One table for the report, straight to Word, ready to paste: (1) clustered, (2) robust.
*    collect is Stata's own table system (etable and dtable are built on it). Each line
*    below sets one thing you can see in the table. To adapt it: change the labels and the note.
collect clear
collect create regtable
*    Put each stored model into the table: its column number, its name, and two Yes/No rows
estimates restore clustered
quietly collect _r_b _r_se _r_p e(N) e(r2), tag(model[(1)] method[cl]): estimates replay
collect get firmfe = "No" yearfe = "Yes", tags(model[(1)] method[cl])
estimates restore robust
quietly collect _r_b _r_se _r_p e(N) e(r2), tag(model[(2)] method[rob]): estimates replay
collect get firmfe = "No" yearfe = "Yes", tags(model[(2)] method[rob])
*    Column heads and row labels (short labels here; the variable labels stay as they are)
collect label levels method cl "Clustered SE" rob "Robust SE", modify
collect label levels colname ai_firm "AI firm" ln_emp "Log employees" ln_cap "Log capital", modify
collect label levels result firmfe "Firm fixed effects" yearfe "Year effects" N "Observations" ///
    r2 "R-squared", modify
*    Numbers: three decimals, standard errors in parentheses, stars on the coefficient
collect style cell result[_r_b _r_se], nformat(%9.3f)
collect style cell result[_r_se], sformat("(%s)")
collect style cell result[N], nformat(%9.0fc)
collect style cell result[r2], nformat(%9.2f)
collect stars _r_p 0.01 "***" 0.05 "**" 0.1 "*", attach(_r_b)
*    Look: no label on coefficient and SE rows, centred numbers, no vertical line,
*    a line between the coefficients and the rows below them
collect style header result[_r_b _r_se], level(hide)
collect style cell, halign(center)
collect style cell cell_type[row-header], halign(left)
collect style cell border_block, border(right, pattern(nil))
collect style cell result[firmfe], border(top, pattern(single))
*    Rows: each variable (coefficient, SE below), then the other rows. Columns: (1), then the name
collect layout (colname[ai_firm ln_emp ln_cap]#result[_r_b _r_se] ///
    result[firmfe yearfe N r2]) (model#method)
collect title "Table 2. AI adoption and financial expenses: pooled OLS"
collect notes "Notes: The dependent variable is log financial expenses."
collect notes "Standard errors in parentheses: clustered by firm in (1), robust in (2)."
collect notes "*** p<0.01, ** p<0.05, * p<0.1."
collect preview
collect export "$root/output/tables/regressions.docx", replace

log close
