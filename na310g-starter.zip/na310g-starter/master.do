* =====================================================================
* PURPOSE  Run the whole project, from raw data to tables, in order
* INPUTS   data/raw/
* OUTPUTS  data/processed/, output/tables/, output/logs/
* CREATED  <date>, <your code>
* =====================================================================
* HOW TO START: double-click this file. Stata then opens IN this folder, and the
* line below remembers where the project is. (Or: File > Change Working Directory,
* choose this folder, then run this file.)
version 18
global root "`c(pwd)'"
do "$root/dofiles/0_settings.do"

do "$root/dofiles/1_load_check.do"
do "$root/dofiles/2_sample_vars.do"
do "$root/dofiles/3_descriptives.do"
do "$root/dofiles/4_regressions.do"

display "Done: everything rebuilt from the raw data in $root"
