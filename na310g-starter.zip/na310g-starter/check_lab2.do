* =====================================================================
* PURPOSE  Lab 2 self-check: run it after each block. It says OK, or what differs.
*          Usage:  do "$root/check_lab2.do"
* CREATED  26 Oct 2026, generated from the teacher's demo run (build_lab2.py)
* =====================================================================
* For the DEMO question (financial expenses). On your own data it will complain.
if "$root" == "" {
    display as error "Run master.do first: Stata does not know where your project is."
    exit
}
capture confirm file "$root/data/processed/sample.dta"
if _rc {
    display as error `"No sample yet: run Lab 1 first, or: do "$root/lab1-catchup/catchup_after_B.do""'
    exit
}
preserve
use "$root/data/processed/sample.dta", clear
quietly xtset firmID year

* --- Block E: fixed effects
capture quietly xtreg ln_fin ai_firm ln_emp ln_cap i.year, fe vce(cluster firmID)
if _rc {
    display as error "E: the fixed-effects regression did not run (error " _rc "). Check the variable names."
    restore
    exit
}
capture assert abs(_b[ai_firm] - -0.051784) < 0.0001
if _rc display as error "E: the FE coefficient on your sample is " %6.3f _b[ai_firm] ", expected -0.052. Lost? do $root/lab2-catchup/catchup_after_E.do"
else display as result "E: OK, FE coefficient -0.052: smaller than pooled OLS, as the exit question asked."

* --- Block G: IV
capture confirm variable daioe_main
if _rc {
    display as error "G: daioe_main is missing: see the merge in 2_sample_vars.do."
    restore
    exit
}
quietly keep if !missing(daioe_main)
capture quietly ivregress 2sls ln_fin (ai_firm = daioe_main) ln_emp ln_cap i.year, vce(cluster firmID)
if _rc display as error "G: the IV regression did not run (error " _rc ")."
else {
    capture assert abs(_b[ai_firm] - 3.694116) < 0.001
    if _rc display as error "G: the IV coefficient is " %6.3f _b[ai_firm] ", expected 3.694. Lost? do $root/lab2-catchup/catchup_after_G.do"
    else display as result "G: OK, IV coefficient 3.694: compare it with OLS. Believable?"
}
restore
