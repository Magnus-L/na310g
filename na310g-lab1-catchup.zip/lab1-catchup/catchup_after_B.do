* Lost during block B? This runs the teacher's code for the demo and copies it
* into your dofiles/ (it REPLACES what is there). Then continue with block C.
* Run master.do first: it sets $root, the project folder.
copy "$root/lab1-catchup/1_load_check.do" "$root/dofiles/1_load_check.do", replace
do "$root/lab1-catchup/1_load_check.do"
copy "$root/lab1-catchup/2_sample_vars.do" "$root/dofiles/2_sample_vars.do", replace
do "$root/lab1-catchup/2_sample_vars.do"
copy "$root/lab1-catchup/3_descriptives.do" "$root/dofiles/3_descriptives.do", replace
do "$root/lab1-catchup/3_descriptives.do"
display as result "Caught up: continue with block C."
